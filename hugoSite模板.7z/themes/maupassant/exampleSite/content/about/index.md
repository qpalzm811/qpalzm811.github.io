---
title: "关于我"
date: 2015-03-10 00:13:27
description: 《Go 实战笔记》系列作者，《Golang Gin 实战》系列作者，《Android Gradle权威指南》作者，现负责技术管理
---

《Go 实战笔记》系列作者，《Golang Gin 实战》系列作者，《Android Gradle权威指南》作者，现负责技术管理。

[Android Gradle权威指南](http://yuedu.baidu.com/ebook/14a722970740be1e640e9a3e)

公众号，扫码关注

![扫码关注](qrcode_for_weixin.jpg)


